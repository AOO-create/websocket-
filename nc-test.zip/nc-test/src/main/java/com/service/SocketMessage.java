package com.service;

public enum SocketMessage implements SocketResult{
//    HEART_MESSAGE,READ_MESSAGE;
    HEART_MESSAGE(){
        @Override
        public String getResult(String a) {
            return a;
        }
    },
    READ_MESSAGE(){
        @Override
        public String getResult(String a) {
            return a;
        }
    }

}