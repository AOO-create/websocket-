package com.service;

public interface SocketResult {
    String getResult(String a);
}
